
$(document).ready(function () {
    var table = $('#schedule-table').DataTable({
        // ajax: data,
        "pageLength" : 25,
        scrollX: true,
        columnDefs: [
            { "width": "200px", targets: "_all" },
            { "className": "salary-table", targets: "_all" } 
        ]
    });
    $('#payroll-range').daterangepicker({
        startDate: moment(),
        endDate: moment().add(7, 'day'), 
        dateLimit: { days: 30 },
        locale: { format: 'YYYY-MM-DD' }
    });
    $('.open-add-form').click(function() {
        $('#add-form-popup').hide(100).fadeIn(300); // SHOWS POPUP FORM
   
    }),
    $('#close-add-form').click(function() {
        $('#add-form-popup').show(100).fadeOut(300); 
    }); //HIDES POPUP
    $('#generate-payroll').click(function(){
        var confirmGen = confirm("You will be generating payroll based on your range. Are you sure?");
        if(confirmGen){
            var obj = {empType: $('#staff-type').val(), range: $('#payroll-range').val()}
            console.log(obj);
            $.ajax({
                type: "POST",
                url: "ajax/emp_salary.php",
                data: {data: JSON.stringify(obj), command: 'calculate-payroll'},
                success: function(response){
                    if(response.split(' ')[0] == "ERROR:"){
                        alert(response);
                    }else{
                        alert("Succesful. Payroll Generated.");
                        location.reload();
                    }
                }
            });

        }
    });
    var salId;
    // For View Popup
    $('.view-report').click(function(){
        console.log("WORKING");
        $('#view-payroll-popup').hide(100).fadeIn(300);
        salId = $(this).closest('tr').find('td:nth-child(1)').text();
 
        // Queries salary id to get other details
        $.ajax({
            type: "POST",
            url: "ajax/emp_salary.php",
            data: "command=get-payroll&salary-id=" + salId  
        }).done(function(result) { 
            var myJson = JSON.parse(result);  
            console.log(result);         
            var dateStart = new Date(myJson[0]['payroll_date_start']).toLocaleDateString('en-EN', {
                month: 'long',
                day: 'numeric'
                });   
            var dateEnd = new Date(myJson[0]['payroll_date_end']).toLocaleDateString('en-EN', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });   
            $('#view-days-worked').text(myJson[0]['days_worked']);
            $('#view-basic-pay').text(myJson[0]['basic_pay']);
            $('#view-gross-pay').text(myJson[0]['grosspay']);
            $('#view-pag-ibig').text(myJson[0]['pagibig']);
            $('#view-philhealth').text(myJson[0]['philhealth']);
            $('#view-sss').text(myJson[0]['sss']);
            $('#view-net-pay').text( "\u20B1" + myJson[0]['netpay']);
            $('#view-emp-id').text(myJson[0]['emp_id'])
            $('#view-date-range').text( dateStart + " - " + dateEnd);
            console.log(myJson[0]['deduction']);

        });
    });
    $('#close-view-report').click(function(){
        $('#view-payroll-popup').show(100).fadeOut(300);
    });
    //For Edit Popup
    $('.edit-report').click(function(){
        salId = $(this).closest('tr').find('td:nth-child(1)').text();
        $.ajax({
            type: "POST",
            url: "ajax/emp_salary.php",
            data: "command=get-payroll&salary-id=" + salId  
        }).done(function(result) { 
            var myJson = JSON.parse(result);
            console.log(myJson);         
            var dateStart = new Date(myJson[0]['payroll_date_start']).toLocaleDateString('en-EN', {
                month: 'long',
                day: 'numeric'
                });   
            var dateEnd = new Date(myJson[0]['payroll_date_end']).toLocaleDateString('en-EN', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });   
            $('#edit-payroll-popup').hide(100).fadeIn(300);
            $('#edit-days-worked').val(myJson[0]['days_worked']);
            $('#edit-basic-pay').val(myJson[0]['basic_pay']);
            $('#edit-gross-pay').val(myJson[0]['grosspay'])
            $('#edit-pag-ibig').val(myJson[0]['pagibig']);
            $('#edit-philhealth').val(myJson[0]['philhealth']);
            $('#edit-sss').val(myJson[0]['sss']);
            $('#edit-date-range').text( dateStart + " - " + dateEnd);
            $('#edit-net-pay').val(myJson[0]['netpay']);
        });
        
    });
    // Change Gross Pay during edit input event - Calculation of Payroll
    $('.amount.edit').on("propertychange change keyup input paste", function(event){
        console.log();
        var grossPay = $('#edit-days-worked').val() * $('#edit-basic-pay').val();
        var netpay = grossPay - $('#edit-philhealth').val() - $('#edit-sss').val() - $('#edit-pag-ibig').val();
        console.log(netpay);
        $('#edit-gross-pay').val(grossPay);
        $('#edit-net-pay').val(netpay);
    });
    // ============
    // Close Payroll
    $('#close-edit-report').click(function(){
        $('#edit-payroll-popup').show(100).fadeOut(300);
    });
    // =================

    // Delete Report Button
    $('.delete-report').click(function(){
        salId = $(this).closest('tr').find('td:nth-child(1)').text();
        var confirmDel = confirm('Confirm Deletion of ' + salId  + '?');
        if(confirmDel){
            $.ajax({
                type: "POST",
                url: "ajax/emp_salary.php",
                data: "command=delete-payroll&salary-id=" + salId  
            }).done(function(result) { 
                alert("Deleted Succesfully");
                location.reload();
            });
        }
    });
    // Update Payroll Button
    $('.update-payroll').click(function(){
        var confirmUpdate = confirm("Confirm update of " + salId + "?");
        // console.log(salId);
        if(confirmUpdate){
            let form = document.querySelector('#edit-form');
            //get all field data
            //returns a FormData object
            let data = new FormData(form);
            let obj = serialize(data);
            console.log(obj);
            $.ajax({
                type: "POST",
                url: "ajax/emp_salary.php",
                data: {updateData: JSON.stringify(obj), command: "update-payroll", 'salary-id': salId}
            }).done(function(result) { 
                if(result.split(" ")[0] != "ERROR:"){
                    alert("Updated Succesfully.");
                    console.log(result);
                    // location.reload();
                }
            });
        }
    });
    function serialize (data) {
        let obj = {};
        for (let [key, value] of data) {
            if (obj[key] !== undefined) {
                if (!Array.isArray(obj[key])) {
                    obj[key] = [obj[key]];
                }
                obj[key].push(value);
            } else {
                obj[key] = value;
            }
        }
        return obj;
    }
});