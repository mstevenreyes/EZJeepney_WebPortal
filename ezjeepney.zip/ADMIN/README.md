# Majetsco
  Majetsco Attendance System with fingerprint scanning and online portal, salary forecasting
